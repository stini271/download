<?php
// 404.php - Halaman tidak ditemukan
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>404 - Halaman Tidak Ditemukan</title>
  <meta name="robots" content="noindex, nofollow">
  <style>
    body { font-family: Arial,sans-serif; text-align: center; padding: 50px; }
    h1 { color: #c00; }
    a { color: #003366; text-decoration: none; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <h1>404 - Halaman Tidak Ditemukan</h1>
  <p>Maaf, halaman yang Anda cari tidak tersedia.</p>
  <p><a href="./">Kembali ke Beranda</a></p>
</body>
</html>
